#ifndef BOAT_H
#define BOAT_H

class Server;
class Client;
struct boat{
	Server* server;
	Client* client;
};
#endif
