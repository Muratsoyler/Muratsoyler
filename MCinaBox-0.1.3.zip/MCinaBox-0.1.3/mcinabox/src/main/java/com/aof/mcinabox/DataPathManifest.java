package com.aof.mcinabox;

public class DataPathManifest extends com.aof.sharedmodule.Data.DataPathManifest{}
