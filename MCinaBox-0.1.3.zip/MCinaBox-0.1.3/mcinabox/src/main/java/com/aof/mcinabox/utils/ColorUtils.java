package com.aof.mcinabox.utils;


/**
 * Created by HaiyuKing
 * Used Color工具类（color整型、rgb数组、16进制互相转换）
 */

public class ColorUtils extends com.aof.sharedmodule.Tools.ColorUtils{}
