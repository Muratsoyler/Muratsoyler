package com.aof.mcinabox.launcher.keyboard;

import android.content.Context;

public class GameButton extends com.aof.sharedmodule.Button.GameButton{
    public GameButton(Context context){
        super(context);
    }
}
