package com.aof.mcinabox.launcher.json;

public class KeyboardJson extends com.aof.sharedmodule.Model.KeyboardJsonModel {
    public KeyboardJson(String keyName, int keySizeW, int keySizeH, float keyLX, float keyLY, String keyMain, String specialOne, String specialTwo, boolean isAutoKeep, boolean isHide, boolean isMult, int mainPos, int specialOnePos, int specialTwoPos, String colorhex, int radius) {
        super(keyName,keySizeW,keySizeH,keyLX,keyLY,keyMain,specialOne,specialTwo,isAutoKeep,isHide,isMult,mainPos,specialOnePos,specialTwoPos,colorhex,radius);
    }

}
