package com.aof.mcinabox.launcher.json;

import java.io.Serializable;

public class ArgsJson extends com.aof.sharedmodule.Model.ArgsModel implements Serializable {}
